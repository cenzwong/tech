# CNN for MNIST handwritten digit classification

# To run this script on enmcomp3 and enmcomp11 with GPU, type the following
# bash
# export PATH=$HOME/anaconda3/bin:/usr/local/cuda-8.0/bin:$PATH
# export LD_LIBRARY_PATH=/usr/local/cuda-8.0/lib64:/usr/local/cuda-7.5/lib64
# source activate tf-py3.6
# python3 mnist_cnn.py
# source deactivate tf-py3.6

from __future__ import print_function

import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras import backend as K
from keras.layers.normalization import BatchNormalization
import tensorflow as tf

# Use 1/3 of the GPU memory so that the GPU can be shared by multiple users
gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.333)
sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))

batch_size = 128
num_classes = 10
epochs = 20

# input image dimensions
img_rows, img_cols = 28, 28

# the data, shuffled and split between train and test sets
(x_train, y_train), (x_test, y_test) = mnist.load_data()

if K.image_data_format() == 'channels_first':
    x_train = x_train.reshape(x_train.shape[0], 1, img_rows, img_cols)
    x_test = x_test.reshape(x_test.shape[0], 1, img_rows, img_cols)
    input_shape = (1, img_rows, img_cols)
else:
    x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
    x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)
    input_shape = (img_rows, img_cols, 1)

# Use 2500 training samples only
#import numpy as np
#idx = np.random.randint(0, x_train.shape[0], 2500)
#x_train = x_train[idx]
#y_train = y_train[idx]

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255
print('x_train shape:', x_train.shape)
print(x_train.shape[0], 'train samples')
print(x_test.shape[0], 'test samples')

# convert class vectors to binary class matrices
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

# Define CNN
model = Sequential()
model.add(Conv2D(64, kernel_size=(3, 3), activation='sigmoid',
                 input_shape=input_shape))
model.add(BatchNormalization()) # speedup the training
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25)) # prevent overfitting
model.add(Conv2D(64, (3, 3), activation='sigmoid'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))
model.add(Flatten())
for i in range(0,3):
    model.add(Dense(128, activation='relu')) # orignally 128
    model.add(BatchNormalization())
    model.add(Dropout(0.5))
model.add(Dense(num_classes, activation='softmax'))
model.summary()

model.compile(loss=keras.losses.categorical_crossentropy,
              optimizer='rmsprop',
              metrics=['accuracy'])

model.fit(x_train, y_train,
          batch_size=batch_size,
          epochs=epochs,
          verbose=1, shuffle=False,
          validation_data=(x_test, y_test))
score = model.evaluate(x_test, y_test, verbose=0)
print('Test loss:', score[0])
print('Test accuracy: %.2f%%' % (score[1]*100))

# Save the model to models/ directory. 
# Use keras.models.load_model() to load the model
model_file = 'models/mnist_cnn.h5'
print('Saving CNN to %s' % model_file)
model.save(model_file)


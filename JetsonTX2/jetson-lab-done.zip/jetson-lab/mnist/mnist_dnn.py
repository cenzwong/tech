# DNN for MNIST handwritten digit classification

# Usage:
#   python3 mnist_dnn.py

from __future__ import print_function
import keras
from keras.datasets import mnist
from myDNN import train_dnn, test_dnn
import numpy as np
import tensorflow as tf

batch_size = 128
num_classes = 10
epochs = 10
n_hiddens = [1,1,1]

# input image dimensions
img_rows, img_cols = 28, 28

# Load and normalize MNIST digits
(x_train, trn_lbs), (x_test, tst_lbs) = mnist.load_data()
x_train = x_train.astype('float32') / 255.
x_test = x_test.astype('float32') / 255.
x_train = x_train.reshape((len(x_train), np.prod(x_train.shape[1:])))
x_test = x_test.reshape((len(x_test), np.prod(x_test.shape[1:])))
print('x_train shape:', x_train.shape)
print(x_train.shape[0], 'train samples')
print(x_test.shape[0], 'test samples')

# Convert class vectors to binary class matrices (one-hot)
y_train = keras.utils.to_categorical(trn_lbs, num_classes)
y_test = keras.utils.to_categorical(tst_lbs, num_classes)

# Use 1/3 of the GPU memory so that the GPU can be shared by multiple users
gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.333)
sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))

# Train a DNN
dnn = train_dnn(x_train, y_train, x_test, y_test, n_hiddens=n_hiddens,
                optimizer='adam', act='relu', n_epochs=epochs, bat_size=batch_size, verbose=1)

# Test the DNN
train_acc, _, _ = test_dnn(x_train, trn_lbs, dnn)
test_acc, _, _ = test_dnn(x_test, tst_lbs, dnn)
print('Train accuracy: %.2f%% ' % (train_acc * 100))
print('Test accuracy: %.2f%% ' % (test_acc * 100))